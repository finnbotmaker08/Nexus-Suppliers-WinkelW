CREATE TABLE "shop_orders" (
	"id" text PRIMARY KEY,
	"email" text NOT NULL,
	"items" jsonb NOT NULL,
	"total_minor" integer NOT NULL,
	"status" text DEFAULT 'awaiting_payment' NOT NULL,
	"customer_hash" text NOT NULL,
	"approval_hash" text,
	"owner_notified" boolean DEFAULT false NOT NULL,
	"customer_notified" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"approved_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "shop_products" (
	"slug" text PRIMARY KEY,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"category" text NOT NULL,
	"price_minor" integer,
	"stock" integer,
	"image_url" text NOT NULL,
	"quote_only" boolean DEFAULT false NOT NULL,
	"sort_order" integer NOT NULL
);
