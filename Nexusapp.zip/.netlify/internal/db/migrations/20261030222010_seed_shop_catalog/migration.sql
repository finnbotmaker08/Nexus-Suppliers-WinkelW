INSERT INTO shop_products (slug,name,description,category,price_minor,stock,image_url,quote_only,sort_order) VALUES
('discord-nitro-basic','Discord Nitro Basic','Discord Nitro Basic is currently out of stock.','Discord Nitro',NULL,0,'/products/nitro.svg',false,0),
('discord-nitro-premium','Discord Nitro Premium','Discord Nitro Premium. Open a ticket after payment approval to arrange delivery.','Discord Nitro',800,NULL,'/products/nitro.svg',false,1),
('online-community-members','Online Community Members (per 100)','Each unit contains 100 online community members. Share your server details in your delivery ticket.','Discord Members (Online)',300,NULL,'/products/members.svg',false,2),
('custom-discord-server','Custom Discord Server Development','Communicate in a ticket what you like. Tell us your preferred channels, roles and style for a custom quote.','Discord Decoration & Setup',NULL,NULL,'/products/setup.svg',true,3),
('14-server-boosts','14x Server Boosts','14 Discord server boosts. Share your server in a ticket after payment approval.','Discord Server Boosting Packages',425,NULL,'/products/boosts.svg',false,4),
('14-server-boosts-3-months','14x Server Boosts (3 Months Duration)','14 Discord server boosts with a 3 month duration. Delivery is arranged in a ticket after approval.','Discord Server Boosting Packages',1250,NULL,'/products/boosts.svg',false,5),
('20-server-boosts','20x Server Boosts','20 Discord server boosts. Share your server in a ticket after payment approval.','Discord Server Boosting Packages',790,NULL,'/products/boosts.svg',false,6),
('20-server-boosts-3-months','20x Server Boosts (3 Months Duration)','20 Discord server boosts with a 3 month duration. Delivery is arranged in a ticket after approval.','Discord Server Boosting Packages',1500,NULL,'/products/boosts.svg',false,7),
('28-server-boosts','28x Server Boosts','28 Discord server boosts. Share your server in a ticket after payment approval.','Discord Server Boosting Packages',950,NULL,'/products/boosts.svg',false,8),
('28-server-boosts-3-months','28x Server Boosts (3 Months Duration)','28 Discord server boosts with a 3 month duration. Delivery is arranged in a ticket after approval.','Discord Server Boosting Packages',2500,NULL,'/products/boosts.svg',false,9),
('50-server-boosts','50x Server Boosts','50 Discord server boosts. Share your server in a ticket after payment approval.','Discord Server Boosting Packages',2000,NULL,'/products/boosts.svg',false,10),
('50-server-boosts-3-months','50x Server Boosts (3 Months Duration)','50 Discord server boosts with a 3 month duration. Delivery is arranged in a ticket after approval.','Discord Server Boosting Packages',4500,NULL,'/products/boosts.svg',false,11),
('roblox-2009-2015','Account Years (2009 - 2015)','OG Roblox account from 2009–2015. Ask about the available account years in your delivery ticket.','OG Roblox Accounts',300,NULL,'/products/roblox.svg',false,12),
('roblox-2005-2010','Account Years (2005 - 2010)','OG Roblox account from 2005–2010. Ask about the available account years in your delivery ticket.','OG Roblox Accounts',500,NULL,'/products/roblox.svg',false,13)
ON CONFLICT (slug) DO NOTHING;
